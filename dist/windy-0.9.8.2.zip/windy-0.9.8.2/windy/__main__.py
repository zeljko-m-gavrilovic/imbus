'''
Created on Feb 26, 2016

@author: zeljko.gavrilovic
'''
import windy.gui.application

windy.gui.application.main()